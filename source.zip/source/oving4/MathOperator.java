package oving4;

public enum MathOperator {
	PLUS,
	MINUS,
	MULTIPLY,
	DIVIDE;
}
